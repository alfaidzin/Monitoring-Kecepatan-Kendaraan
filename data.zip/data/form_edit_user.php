<!DOCTYPE html>
<html>
<head>
	<title>form edit user</title>
</head>
<body>
	<?php
	  $kiriman = $_GET["id_kendaraan"];
	  include "koneksi.php";
	  $q = "SELECT * FROM kendaraan WHERE id_kendaraan='$kiriman'";
	  $result = mysqli_query($koneksi,$q);
	  $row = mysqli_fetch_assoc($result);
	?>
		<section class="utama" id="section1">
					<div class="content">
						<div class="form">
	<h1>Form Edit Kendaraan</h1>
		<form action="edit_user.php" method="post" enctype="multipart/form-data">
		<input type="hidden" name="id_kendaraan" value="<?php echo $row["id_kendaraan"];?>">
		<input type="text" name="nama_kendaraan" placeholder="nama lengkap" value="<?php echo $row["nama_kendaraan"]; ?>"><p/>
		<input type="submit" value="Simpan">	
	</form>

						</div>
					</div>
				</section>

		</div>
		<link rel="stylesheet" type="text/css" href="form_edit.css">
	<script type="text/javascript" src="script.js"></script>
</body>
</html>