<?php
	$server ="localhost"; 
	$user	="id10540959_root";
	$psw	="yandra";
	$db="id10540959_mynotescode";

	$koneksi = mysqli_connect($server,$user,$psw,$db);

?>