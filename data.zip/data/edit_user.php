<?php 
// koneksi database
include 'koneksi.php';
 
// menangkap data yang di kirim dari form
$id_kendaraan = $_POST['id_kendaraan'];
$nama_kendaraan = $_POST['nama_kendaraan'];
 
// update data ke database
mysqli_query($koneksi,"update kendaraan set nama_kendaraan='$nama_kendaraan' where id_kendaraan='$id_kendaraan'");
 
// mengalihkan halaman kembali ke index.php
header("location:tampil.php");
 
?>